./cmd_start  h9-miner-spacemesh-linux-amd64 5 1
